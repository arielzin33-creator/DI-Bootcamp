# Display and parse JSON data demo

## Setup
```
npm install
npm run dev
```
Build: `npm run build`

## Files
- `src/data/data.json` — copied verbatim from the linked source file
  (SocialMedias array, Experiences array with nested roles, Skills
  array with nested SkillSet)
- `src/Example1.jsx` — class component, renders `SocialMedias`
- `src/Example2.jsx` — class component, renders `Skills` (nested:
  Area → SkillSet)
- `src/Example3.jsx` — class component, renders `Experiences` (nested:
  company → roles), with a `key` on every `<div>` produced by a `.map()`
- `src/App.jsx` — imports and renders all three

## Note on file naming
Same as the previous two exercises: components are named `.jsx`
rather than `.js` because this project uses Vite, which only parses
JSX in `.jsx`/`.tsx` files by default. Rename to `.js` with no code
changes if you're using `create-react-app` instead.
