import React from "react";
import data from "./data/data.json";

/**
 * Example3
 *
 * Displays the Experiences array — each experience has a nested
 * "roles" array. The exercise specifically asks for a `key` on every
 * new <div> created while mapping, which matters here because there
 * are two separate .map() calls (companies, then each company's
 * roles) each producing their own <div> elements.
 */
class Example3 extends React.Component {
  render() {
    return (
      <div style={styles.section}>
        <h2>Example3 — Experiences</h2>
        {data.Experiences.map((experience) => (
          <div key={experience.companyName} style={styles.company}>
            <img
              src={experience.logo}
              alt={experience.companyName}
              width={40}
              height={40}
            />
            <h3>
              <a href={experience.url} target="_blank" rel="noreferrer">
                {experience.companyName}
              </a>
            </h3>

            {experience.roles.map((role) => (
              <div key={role.title} style={styles.role}>
                <p style={styles.roleTitle}>{role.title}</p>
                <p>{role.description}</p>
                <p style={styles.roleMeta}>
                  {role.startDate} – {role.endDate} · {role.location}
                </p>
              </div>
            ))}
          </div>
        ))}
      </div>
    );
  }
}

const styles = {
  section: {
    marginBottom: "24px",
  },
  company: {
    marginBottom: "16px",
    paddingBottom: "16px",
    borderBottom: "1px solid #e0e0e0",
  },
  role: {
    marginLeft: "8px",
  },
  roleTitle: {
    fontWeight: 500,
    margin: "4px 0",
  },
  roleMeta: {
    fontSize: "13px",
    color: "#666",
  },
};

export default Example3;
