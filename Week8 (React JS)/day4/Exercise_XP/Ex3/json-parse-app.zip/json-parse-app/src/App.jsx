import React from "react";
import Example1 from "./Example1.jsx";
import Example2 from "./Example2.jsx";
import Example3 from "./Example3.jsx";

function App() {
  return (
    <div style={{ padding: "24px", fontFamily: "sans-serif", maxWidth: "560px" }}>
      <h1>Display JSON data</h1>
      <Example1 />
      <Example2 />
      <Example3 />
    </div>
  );
}

export default App;
