import React from "react";
import data from "./data/data.json";

/**
 * Example2
 *
 * Displays the Skills data — a first-level array of skill areas, each
 * containing a second-level array (SkillSet) of individual skills.
 * This is the "inner array up to the second level" the exercise
 * mentions, so it's rendered with a nested .map().
 */
class Example2 extends React.Component {
  render() {
    return (
      <div style={styles.section}>
        <h2>Example2 — Skills</h2>
        {data.Skills.map((group) => (
          <div key={group.Area} style={styles.group}>
            <h3>{group.Area}</h3>
            <ul>
              {group.SkillSet.map((skill) => (
                <li key={skill.Name}>
                  {skill.Name}
                  {skill.Hot && <span style={styles.hotBadge}>hot</span>}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    );
  }
}

const styles = {
  section: {
    marginBottom: "24px",
  },
  group: {
    marginBottom: "12px",
  },
  hotBadge: {
    marginLeft: "8px",
    fontSize: "11px",
    padding: "2px 6px",
    borderRadius: "999px",
    backgroundColor: "#fde2e2",
    color: "#a33",
  },
};

export default Example2;
