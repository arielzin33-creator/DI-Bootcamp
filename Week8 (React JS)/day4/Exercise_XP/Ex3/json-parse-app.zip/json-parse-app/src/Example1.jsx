import React from "react";
import data from "./data/data.json";

/**
 * Example1
 *
 * Displays the top-level SocialMedias array — a flat array of URL
 * strings, the simplest of the three shapes in data.json.
 */
class Example1 extends React.Component {
  render() {
    return (
      <div style={styles.section}>
        <h2>Example1 — Social medias</h2>
        <ul>
          {data.SocialMedias.map((url) => (
            <li key={url}>
              <a href={url} target="_blank" rel="noreferrer">
                {url}
              </a>
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

const styles = {
  section: {
    marginBottom: "24px",
  },
};

export default Example1;
